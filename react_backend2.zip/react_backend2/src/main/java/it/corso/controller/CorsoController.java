package it.corso.controller;

import it.corso.jwt.JWTTokenNeeded;
import it.corso.jwt.Secured;
import jakarta.ws.rs.Path;


@Secured(role = "admin")
@JWTTokenNeeded
@Path("/corsi")
public class CorsoController {

}
