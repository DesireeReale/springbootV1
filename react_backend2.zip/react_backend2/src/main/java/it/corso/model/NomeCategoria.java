package it.corso.model;

public enum NomeCategoria {
	FrontEnd,
	 BackEnd,
	 FullStack,
	 Cybersecurity
}
