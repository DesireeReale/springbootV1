package it.corso.model;

public enum Tipologia {
	Admin,
	 Utente,
	 Docente
}
