package it.corso.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "corso")
public class Corso {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_C")
	private int id;
	
	@Column(name = "Nome_Corso")
	private String nomeCorso; 
	
	@Column(name = "Descrizione_breve")
	private String descrizioneBreve;
	
	@Column(name = "Descrizione_completa")
	private String descrizioneCompleta;

	@Column(name = "Durata")
	private String durata;
	
	@ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinTable(
			//essendo JoinTable devo passare il nome delle tabelle
			name = "utenti_corsi", joinColumns = @JoinColumn(name = "FK_CU", referencedColumnName = "ID_C"),
			inverseJoinColumns = @JoinColumn(name = "FK_UC", referencedColumnName = "ID_U")
			)
	List<Utente> utenti= new ArrayList<>();
	

	@ManyToOne(cascade = CascadeType.REFRESH)
	@JoinColumn(name = "FK_CA", referencedColumnName = "ID_CA")
	//ho una chiave che si referenzia all'Id della tabella corso (FK_CA)
	// name non si passa il nome della tabella perchè è JoinColumn --> si passa il nome della chiave esterna		
	private Categoria categoria; //avendo ManyToOne ho solo un oggetto e non una lista
	
	
	
	public String getDurata() {
		return durata;
	}
	public void setDurata(String durata) {
		this.durata = durata;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNomeCorso() {
		return nomeCorso;
	}

	public void setNomeCorso(String nomeCorso) {
		this.nomeCorso = nomeCorso;
	}

	public String getDescrizioneBreve() {
		return descrizioneBreve;
	}

	public void setDescrizioneBreve(String descrizioneBreve) {
		this.descrizioneBreve = descrizioneBreve;
	}

	public String getDescrizioneCompleta() {
		return descrizioneCompleta;
	}

	public void setDescrizioneCompleta(String descrizioneCompleta) {
		this.descrizioneCompleta = descrizioneCompleta;
	}
	public List<Utente> getUtenti() {
		return utenti;
	}
	public void setUtenti(List<Utente> utenti) {
		this.utenti = utenti;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	
	
	
}
