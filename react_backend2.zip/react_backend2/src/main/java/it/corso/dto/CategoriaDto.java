package it.corso.dto;

public class CategoriaDto {

	
}
