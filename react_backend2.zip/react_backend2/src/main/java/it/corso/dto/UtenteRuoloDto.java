package it.corso.dto;


import it.corso.model.Tipologia;


public class UtenteRuoloDto {
	
	private Tipologia tipologia;

	public Tipologia getTipologia() {
		return tipologia;
	}

	public void setTipologia(Tipologia tipologia) {
		this.tipologia = tipologia;
	}

	
}
