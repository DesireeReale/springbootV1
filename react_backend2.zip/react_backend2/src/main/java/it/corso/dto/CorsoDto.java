package it.corso.dto;

public class CorsoDto {

}
