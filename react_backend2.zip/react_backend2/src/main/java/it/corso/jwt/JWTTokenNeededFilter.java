package it.corso.jwt;

import java.io.IOException;
import java.security.Key;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;

import java.util.*;

@JWTTokenNeeded
@Provider
public class JWTTokenNeededFilter implements ContainerRequestFilter{

	//va a iniettare i metodi all'interno della classe
	@Context
	private ResourceInfo resourceInfo;
	
	
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		
		/*
		 .getResourceMethod().getAnnotation controlla se nei metodi c'è @Secured, se esiste le ritorna
		 */
		Secured annotationRole = resourceInfo.getResourceMethod().getAnnotation(Secured.class);
		
		if(annotationRole == null) {
			
			annotationRole = resourceInfo.getResourceClass().getAnnotation(Secured.class);
		}
		
		//prende la richiesta ed estrae AUTHORIZATION che è una costante che evita le eccezione, dentro c'è token -> ruolo
		String autorizationHeader = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
		
		//controlliamo che authorization sia presente e formattato correttamente
		if(autorizationHeader == null || !autorizationHeader.startsWith("Bearer ")) {
			
			throw new NotAuthorizedException("Autorizzazione mancante");
		} 
			
			//estraggo  il token da authorizationHeader
			String token = autorizationHeader.substring("Bearer".length()).trim();
		
			try {
				
				byte[] secret = "stringachiave1234567891111111111".getBytes();
				Key chiaveSegreta = Keys.hmacShaKeyFor(secret);
				
				//prende il token, verifica se la firma è valida e torna i claims (che contengonon le info)
				Jws<Claims> claims = Jwts.parserBuilder().setSigningKey(chiaveSegreta).build().parseClaimsJws(token);
				Claims body = claims.getBody();
				
				List<String> ruoliToken = body.get("ruoli", List.class);
				
				Boolean asRole = false;
				
				for(String ruolo : ruoliToken) {
					
					if(ruolo.equals(annotationRole.role())) {
						asRole = true;
					}
					//se il ruolo non è presente rilancia una risposta unathorized 401
					if(!asRole) {
						requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
					}
				}
				
				//con jax-rs devo registrare
				
			} catch (Exception e) {
				requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
			}
	}

}
