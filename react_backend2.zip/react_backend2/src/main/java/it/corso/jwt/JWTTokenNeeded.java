package it.corso.jwt;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.ws.rs.NameBinding;

/*Annotation che indica che JWTTokenNeeded è un namebind annotation, utilizzata per associare i filtri 
 * di tipo containerRequest filter a specifiche classi o metodi (fa da legante tra il filtro e la classe)
 * Retention indica che JWTTokenNeeded sarà disponibile solo in runtime
 * Target specifica dove poter applicare l'annotation JWTTokenNeeded
 */
@NameBinding
@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.TYPE, ElementType.METHOD })
public @interface JWTTokenNeeded {

	
}
