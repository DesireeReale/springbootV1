package it.corso.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.codec.digest.DigestUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.RuoloDao;
import it.corso.dao.UtenteDao;
import it.corso.dto.UtenteDto;
import it.corso.dto.UtenteDtoAggiornamento;
import it.corso.dto.UtenteLoginRequestDto;
import it.corso.dto.UtenteRegistrazioneDto;
import it.corso.dto.UtenteRuoloDto;
import it.corso.model.Ruolo;
import it.corso.model.Utente;

@Service
public class UtenteServiceImpl implements UtenteService{

	@Autowired
	private UtenteDao utenteDao;
	
	@Autowired
	private RuoloDao ruoloDao;
	
	private ModelMapper mapper = new ModelMapper();
	
	@Override
	public void insert(UtenteRegistrazioneDto utenteDto) {
		
		Utente utente = new Utente();
		
		utente.setNome(utenteDto.getNome());
		utente.setCognome(utenteDto.getCognome());
		utente.setEmail(utenteDto.getEmail());
		
		String sha256hex=DigestUtils.sha256Hex(utenteDto.getPassword());
		utente.setPassword(sha256hex);

		utenteDao.save(utente);
	}



	@Override
	public void UpdateUtenteData(UtenteDtoAggiornamento utente) {

		Utente userDb = utenteDao.findByEmail(utente.getEmail());

		if (userDb != null) {

			// mi setto come prima cosa i valori da update
			userDb.setNome(utente.getNome());
			userDb.setCognome(utente.getCognome());
			userDb.setEmail(utente.getEmail());

			// mi crea la lista
			List<Ruolo> ruoliUtente = new ArrayList<>();

			// cerco tramite id il ruolo

			Optional<Ruolo> ruoliDb = ruoloDao.findById(utente.getIdRuolo());

			if (ruoliDb.isPresent()) {

				// se presente quel ruolo lo prendo e
				Ruolo ruolo = ruoliDb.get();

				// in questa variabile setto l'id da modificare
				ruolo.setId(utente.getIdRuolo());

				// nella lista dei ruolo aggiungo il
				ruoliUtente.add(ruolo);

				// salvo i ruoli nell'utente sovrascrivendoli
				userDb.setRuoli(ruoliUtente);

			} 
			utenteDao.save(userDb);
		} 
	}



	@Override
	public boolean existUtenteByEmail(String email) {
		
		return utenteDao.existsByEmail(email);
	}

	@Override
	public boolean loginUtente(UtenteLoginRequestDto utenteLoginRequestDto) {
		
		//oggetto che useremo per controllare nel db
		Utente utente = new Utente();
		
		utente.setEmail(utenteLoginRequestDto.getEmail());
		utente.setPassword(utenteLoginRequestDto.getPassword());
		
		// hash della password
		String sha256hex = DigestUtils.sha256Hex(utente.getPassword());
		
		Utente credenzialiUtente = utenteDao.findByEmailAndPassword(utente.getEmail(), sha256hex);
		
		// se le credenziali non sono nulle, restituisce true
		return credenzialiUtente != null ? true : false; 
	}
	
	
	//metodo che richiama metodo del DAO
	@Override
	public Utente findByEmail(String email) {
		return utenteDao.findByEmail(email);
	}

	
	@Override
	public List<UtenteRuoloDto> getRuoli(){
		//Faccio la query e riempio la lista con gli utenti
		List<Utente> utenti = (List<Utente>) utenteDao.findAll();
		
		//System.out.println(utenti.size());
		List<UtenteDto> utentiDto = new ArrayList<>();
		
		//con mapper trasformo utente in utenteDto
		for(Utente u : utenti) {
			utentiDto.add(mapper.map(u, UtenteDto.class));
		}
		
		//creo lista ruoli e la riempio con il ruolo dell'utente
		List<UtenteRuoloDto> utenteRuoloDto = new ArrayList<>();
		for(UtenteDto dto : utentiDto) {
			utenteRuoloDto.addAll(dto.getRuoli());
		}
		
		//utentiDto.forEach(u -> System.out.println(u.getTipologia()));
		//utenti.forEach(u -> utentiDto.add(mapper.map(u, UtenteRuoloDto.class)));
		return utenteRuoloDto;
		
	}
	
	
	

	@Override
	public List<UtenteDto> getUtenti() {
		
		List<Utente> utenti = (List<Utente>) utenteDao.findAll();
		
		List<UtenteDto> utentiDto = new ArrayList<>();
		
		//con il forEach aggiungo 1 elemento alla volta --> per questo add e non addAll
		utenti.forEach(u -> utentiDto.add(mapper.map(u, UtenteDto.class)));
		
		return utentiDto;
	}

	
	@Override
	public UtenteDto utenteById(int id) {
		
		Utente utente = utenteDao.findById(id).orElseThrow();
		
		return mapper.map(utente, UtenteDto.class);
	}
	
	
	@Override
	public void deleteUtente(int id) {
		
		utenteDao.deleteById(id);
	}
}
