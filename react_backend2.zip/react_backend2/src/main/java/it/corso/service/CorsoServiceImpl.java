package it.corso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import it.corso.dao.CorsoDao;
import it.corso.model.Corso;

public class CorsoServiceImpl implements CorsoService{

	@Autowired
	private CorsoDao corsoDao;
	
	
	
	@Override
	public void insertCorso(Corso corso) {
		
		corsoDao.save(corso);
		
	}

	@Override
	public Corso getCorsoById(int id) {
		
		//cerca l'oggetto corsoDao, se lo trova lo ritorna oppure mi torna null
		return corsoDao.findById(id).orElseThrow(null);
	}

	@Override
	public void UpdateCorsoData(Corso corso) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Corso> getCorsi() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCorso(int id) {
		// TODO Auto-generated method stub
		
	}

}
