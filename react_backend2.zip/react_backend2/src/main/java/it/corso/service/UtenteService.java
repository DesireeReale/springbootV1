package it.corso.service;

import java.util.List;

import it.corso.dto.UtenteDto;
import it.corso.dto.UtenteDtoAggiornamento;
import it.corso.dto.UtenteLoginRequestDto;
import it.corso.dto.UtenteRegistrazioneDto;
import it.corso.dto.UtenteRuoloDto;
import it.corso.model.Utente;

public interface UtenteService {
	
	// inserimento dati
	void insert(UtenteRegistrazioneDto utenteDto);
	
	// aggiornamento
	void UpdateUtenteData(UtenteDtoAggiornamento utente);
	
	// read(int id)
	UtenteDto utenteById(int id);
		
	List<UtenteDto> getUtenti();
	
	void deleteUtente(int id);
	
	boolean existUtenteByEmail(String email);

	boolean loginUtente(UtenteLoginRequestDto utenteLoginRequestDto);
	
	Utente findByEmail(String email);
	
	List<UtenteRuoloDto> getRuoli();
}
