package it.corso.service;

import java.util.List;

import it.corso.model.Corso;

public interface CorsoService {

	//inserimento Corso nel db
	void insertCorso(Corso corso);
	
	//ritorno corso in base all'id
	Corso getCorsoById(int id);
	
	//aggiorna dati Corso
	void UpdateCorsoData(Corso corso);
	
	//ritorna la lista dei corsi
	List<Corso> getCorsi();
	
	//cancella corso in base all'id
	void deleteCorso(int id);
	
}
