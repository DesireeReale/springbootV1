package it.corso.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.CategoriaDao;
import it.corso.dto.CategoriaDto;
import it.corso.dto.CreateCategoriaDto;
import it.corso.model.Categoria;

@Service
public class CategoriaServiceImpl implements CategoriaService{

	@Autowired
	private CategoriaDao categoriaDao;

	@Override
	public CategoriaDto createCategoria(CreateCategoriaDto categoria) {
		// TODO Auto-generated method stub
		Categoria categoriaNew = new Categoria();
		
		categoriaNew.setNomeCategoria(categoria.getNome_categoria());
		
		categoriaDao.save(categoriaNew);
		
		return new CategoriaDto(categoriaNew.getId(), categoriaNew.getNomeCategoria());
	}
	

}
