package it.corso.service;

import java.util.List;

import it.corso.dto.CorsoDto;
import it.corso.dto.CreateCorsoDto;
import it.corso.dto.UtenteDto;
import it.corso.exception.EntityNotFoundException;
import it.corso.model.Corso;

public interface CorsoService {

	//inserimento Corso nel db
	void insertCorso(Corso corso);
	
	//ritorno corso in base all'id
	Corso getCorsoById(int id);
	
	//aggiorna dati Corso
	void UpdateCorsoData(Corso corso);
	
	//ritorna la lista dei corsi
	List<Corso> getCorsi();
	
	//cancella corso in base all'id
	void deleteCorso(int id);
	
	CorsoDto createCorso(CreateCorsoDto corso) throws EntityNotFoundException;
	
	List<UtenteDto> getUtenti(Integer idCorso, Integer idRuolo) throws EntityNotFoundException;
	
	public List<CorsoDto> searchCorsi(Integer idCategoria) throws EntityNotFoundException;
}
