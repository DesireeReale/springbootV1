package it.corso.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import it.corso.dao.CorsoDao;
import it.corso.dao.UtenteDao;
import it.corso.dto.CorsoDto;
import it.corso.dto.CreateCorsoDto;
import it.corso.dto.UtenteDto;
import it.corso.exception.EntityNotFoundException;
import it.corso.model.Corso;
import it.corso.model.Utente;

public class CorsoServiceImpl implements CorsoService{

	@Autowired
	private UtenteDao utenteDao; 
	
	
	@Autowired
	private CorsoDao corsoDao;
	
	
	@Override
	public void insertCorso(Corso corso) {
		
		corsoDao.save(corso);
		
	}

	@Override
	public Corso getCorsoById(int id) {
		
		//cerca l'oggetto corsoDao, se lo trova lo ritorna oppure mi torna null
		return corsoDao.findById(id).orElseThrow(null);
	}

	@Override
	public void UpdateCorsoData(Corso corso) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Corso> getCorsi() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCorso(int id) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	private ModelMapper modelMapper = new ModelMapper();	
	
	@Override
	public CorsoDto createCorso(CreateCorsoDto corso) throws EntityNotFoundException{
		
		Corso corsodb = new Corso();
		
		corsodb = modelMapper.map(corso, Corso.class);
		
		Optional<Utente> docente = utenteDao.findById(corso.getIdDocente());
		
		if(docente.isPresent()) {
			corsodb.getUtenti().add(docente.get());
			
			corsodb = corsoDao.save(corsodb);
			
			return modelMapper.map(corsodb, CorsoDto.class);
		}
		else {
			throw new EntityNotFoundException("utente non trovato");
		}
		
	}
	

	

	@Override
	public List<UtenteDto> getUtenti(Integer idCorso, Integer idRuolo) throws EntityNotFoundException{
		
		Optional<Corso> corso = corsoDao.findById(idCorso); 
		
			
		if(!corso.isPresent()) {
			throw new EntityNotFoundException("corso non trovato");
		}
		
		if(idRuolo == null) {
			return corso.get().getUtenti().stream()
					.filter(u -> u.getRuoli().stream().map(r -> r.getId()).toList().contains(idRuolo))
					.map(u -> modelMapper.map(u, UtenteDto.class)).toList(); 
		}
		else {
		return corso.get().getUtenti().stream().map(u -> modelMapper.map(u, UtenteDto.class)).toList();
		}
	}

	
	
	@Override
	public List<CorsoDto> searchCorsi(Integer idCategoria) throws EntityNotFoundException {
		
		List<Corso> corsi = corsoDao.findByCategoriaId(idCategoria);
		return corsi.stream().map(c -> modelMapper.map(c, CorsoDto.class)).toList();
	} 
	
	
}
