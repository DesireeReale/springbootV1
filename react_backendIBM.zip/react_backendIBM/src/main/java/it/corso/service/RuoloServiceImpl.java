package it.corso.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.RuoloDao;
import it.corso.dto.CreateRuoloDto;
import it.corso.dto.RuoloDto;
import it.corso.model.Ruolo;

@Service
public class RuoloServiceImpl implements RuoloService{

	@Autowired
	private RuoloDao ruoloDao;
	
	@Override
	public RuoloDto createRuolo(CreateRuoloDto ruoloDto) {
		
		
		Ruolo ruolo = new Ruolo(); //creo ruolo partendo da RuoloDto
		ruolo.setTipologia(ruoloDto.getTipologia());
		
		ruolo = ruoloDao.save(ruolo);
		
		
		return new RuoloDto(ruolo.getId(), ruolo.getTipologia()); //devo ritornare un ruoloDto
	}

	@Override
	public List<RuoloDto> getAll() {
		
		List<Ruolo> listRuoli = (List<Ruolo>) ruoloDao.findAll();
		List<RuoloDto> listRuoloDto = new ArrayList<RuoloDto>();
		
		listRuoli.forEach(r -> listRuoloDto.add(new RuoloDto(r.getId(), r.getTipologia())));
		
		return listRuoloDto;
	}
	
}
