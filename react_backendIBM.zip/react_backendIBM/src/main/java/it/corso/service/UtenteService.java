package it.corso.service;

import java.util.List;

import it.corso.dto.CorsoDto;
import it.corso.dto.RuoloDto;
import it.corso.dto.UtenteDto;
import it.corso.dto.UtenteDtoAggiornamento;
import it.corso.dto.UtenteLoginRequestDto;
import it.corso.dto.UtenteRegistrazioneDto;
import it.corso.exception.EntityNotFoundException;
import it.corso.model.Utente;


public interface UtenteService {
	
	// inserimento dati
	void insert(UtenteRegistrazioneDto utenteDto);
	
	// aggiornamento
	void UpdateUtenteData(UtenteDtoAggiornamento utente);
	
	// read(int id)
	UtenteDto utenteById(int id);
		
	List<UtenteDto> getUtenti();
	
	void deleteUtente(int id);
	
	boolean existUtenteByEmail(String email);

	boolean loginUtente(UtenteLoginRequestDto utenteLoginRequestDto);
	
	Utente findByEmail(String email);
	
	List<RuoloDto> getRuoli();
	
	
	RuoloDto addRuoloToUser(Integer id, Integer idRuolo) throws EntityNotFoundException;
	
	CorsoDto subscribeUtente(Integer idUtente, Integer idCorso) throws EntityNotFoundException;
	
	CorsoDto unSubscribeUtente(Integer idUtente, Integer idCorso) throws EntityNotFoundException;
	
	List<UtenteDto> getUtentiByRuolo (Integer idRuolo);
}
