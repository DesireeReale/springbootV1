package it.corso.model;

public class NomeCategoria {
	String FrontEnd;
	String BackEnd;
	String FullStack;
	String Cybersecurity;
	
	
	public String getFrontEnd() {
		return FrontEnd;
	}
	public void setFrontEnd(String frontEnd) {
		FrontEnd = frontEnd;
	}
	public String getBackEnd() {
		return BackEnd;
	}
	public void setBackEnd(String backEnd) {
		BackEnd = backEnd;
	}
	public String getFullStack() {
		return FullStack;
	}
	public void setFullStack(String fullStack) {
		FullStack = fullStack;
	}
	public String getCybersecurity() {
		return Cybersecurity;
	}
	public void setCybersecurity(String cybersecurity) {
		Cybersecurity = cybersecurity;
	}
	
	
}
