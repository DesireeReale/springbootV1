package it.corso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import it.corso.dto.CorsoDto;
import it.corso.dto.CreateCorsoDto;
import it.corso.dto.UtenteDto;
import it.corso.exception.EntityNotFoundException;
import it.corso.service.CorsoService;
import jakarta.websocket.server.PathParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/corso")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CorsoController {

	@Autowired
	private CorsoService corsoService; 
	
	@POST
	public Response createCorso(CreateCorsoDto corso) {
		try {
			CorsoDto corsoSave = corsoService.createCorso(corso);
			
			return Response.status(Response.Status.OK).entity(corsoSave).build();
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	
	
	//era piu utile fare una query personalizzata
	@GET
	@Path("{idCorso}/users")
	public Response getUtenti(@PathParam("idCorso") Integer idCorso, @QueryParam("idRuolo") Integer idRuolo) {
		try {
			
			 List<UtenteDto> utenti = corsoService.getUtenti(idCorso, idRuolo);
			 return Response.status(Response.Status.OK).entity(utenti).build();
		} catch (EntityNotFoundException e) {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}
	
	
	@GET
	public Response searchCorsi(@QueryParam("idCategoria") Integer idCategoria) {
		try {
			
			List<CorsoDto> corsi = corsoService.searchCorsi(idCategoria);
			return Response.status(Response.Status.OK).entity(corsi).build(); 
			
		} catch (Exception e) {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}
}
