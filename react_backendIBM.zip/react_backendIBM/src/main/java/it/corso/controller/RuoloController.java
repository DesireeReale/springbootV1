package it.corso.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import it.corso.dto.CreateRuoloDto;
import it.corso.dto.RuoloDto;
import it.corso.service.RuoloService;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@RestController
@Path("/ruolo")
public class RuoloController {
	
	@Autowired
	RuoloService ruoloService;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/createRuolo")
	public Response createRuolo(@RequestBody CreateRuoloDto ruoloDto) {
		
		RuoloDto newRuoloDto = ruoloService.createRuolo(ruoloDto);
		
		return Response.status(Response.Status.OK).entity(newRuoloDto).build();
		
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getAll() {
		try {
			
		List<RuoloDto> listRuoliDto = ruoloService.getAll();
		return Response.status(Response.Status.OK).entity(listRuoliDto).build();
		} 
		catch(Exception e) {
		return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	
	
}
