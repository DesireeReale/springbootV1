package it.corso.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.security.*;
import java.time.LocalDateTime;

import it.corso.dto.UtenteDto;
import it.corso.dto.UtenteDtoAggiornamento;
import it.corso.dto.UtenteLoginRequestDto;
import it.corso.dto.UtenteLoginResponseDto;
import it.corso.dto.UtenteRegistrazioneDto;
import it.corso.exception.EntityNotFoundException;
import it.corso.dto.CorsoDto;
import it.corso.dto.RuoloDto;
import it.corso.model.Utente;
import it.corso.service.UtenteService;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/utente")
public class UtenteController {

	
	@Autowired
	private UtenteService utenteService;
	
	@POST
	@Path("/registrazione")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response userRegistration(@Valid @RequestBody UtenteRegistrazioneDto utenteDto) {
		
		try {
			// validazione della password
			if(!Pattern.matches("(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{6,20}", utenteDto.getPassword())) {
				return Response.status(Response.Status.BAD_REQUEST).build();
			}
			
			//verifico esistenza utente
			if(utenteService.existUtenteByEmail(utenteDto.getEmail())) {
				return Response.status(Response.Status.BAD_REQUEST).build();
			}
			
			utenteService.insert(utenteDto);
			
			// se va bene ritorna HTTP 200
			return Response.status(Response.Status.OK).build();
		}catch(Exception e) {
			
			// se va male ritorna HTTP 400
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	

	@PUT
	@Path("/aggiornamento")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUser(@RequestBody UtenteDtoAggiornamento utente) {
		try {
			
			utenteService.UpdateUtenteData(utente); 
			return Response.status(Response.Status.OK).build();
			
		} catch (Exception e) {
			
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	
	
	@POST
	@Path("/login")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response loginUtente(UtenteLoginRequestDto utenteLoginRequestDto) {
		try {
			
			//se il login (del service) torna true, nel corpo della risposta devo far tornare il Token
			
			if(utenteService.loginUtente(utenteLoginRequestDto)) {
				return Response.ok(issueToken(utenteLoginRequestDto.getEmail())).build();
			}
			return Response.status(Response.Status.BAD_REQUEST).build();
		} catch (Exception e) {
			
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	
	
	
	@GET
	@Path("/getRuoli")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getRuoli() {
		
		try {
			List<RuoloDto> listaUtenti = utenteService.getRuoli();
			return Response.ok().entity(listaUtenti).build();
		} catch (Exception e) {
			
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	
	
	
	@GET
	@Path("/getUtenti")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUsers(@RequestParam("idRuolo") Integer idRuolo) {
		try {

			List<UtenteDto> listaUtenti = new ArrayList<>();
			
			if(idRuolo == null) {
				listaUtenti = utenteService.getUtenti();
				
			}else {
				listaUtenti = utenteService.getUtentiByRuolo(idRuolo);
			}
			return Response.ok().entity(listaUtenti).build();
			
		} catch (Exception e) {
			
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	
	
	@GET
	@Path("/getUtente/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response utenteById(@PathParam("id") int id) {
		try {
			UtenteDto utenteDto = utenteService.utenteById(id);
			
			return Response.status(Response.Status.OK).entity(utenteDto).build();
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}

	

	@DELETE
	@Path("/elimina/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteUtente(@PathParam("id") int id) {
		try {
			utenteService.deleteUtente(id); 
			return Response.status(Response.Status.OK).build();
			
		} catch (Exception e) {
			
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}
	
	
	
	// NON funziona
	@PUT
	@Path("/{id}/addRuolo/{idRuolo}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addRuoloToUser(@PathParam("id") Integer id, @PathParam("idRuolo") Integer idRuolo) {
		try {
			RuoloDto ruoloDto = utenteService.addRuoloToUser(id, idRuolo);
			return Response.status(Response.Status.OK).entity(ruoloDto).build();
			
		} catch (EntityNotFoundException e) {
			return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
		}
	}
	
	
	
	//NON funziona
	@PUT
	@Path("/{idUtente}/subscribe-corso/{idCorso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response subscribeUtente( @PathParam("idUtente") Integer idUtente, @PathParam("idCorso") Integer idCorso) {
		try {
			
			CorsoDto corso = utenteService.subscribeUtente(idUtente, idCorso);
			
			return Response.status(Response.Status.OK).entity(corso).build();
			
		} catch (EntityNotFoundException e) {
			return Response.status(Response.Status.BAD_REQUEST).build(); 
		}
	}
	
	
	//NON funziona
	@DELETE
	@Path("/{idUtente}/unsubscribe-corso/{idCorso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response unSubscribeUtente( @PathParam("idUtente") Integer idUtente, @PathParam("idCorso") Integer idCorso) {
		try {
			CorsoDto corso = utenteService.unSubscribeUtente(idUtente, idCorso);
			
			return Response.status(Response.Status.OK).entity(corso).build();
		} catch (EntityNotFoundException e) {
			return Response.status(Response.Status.BAD_REQUEST).build(); 
			
		}
	}
	
	
	
	// metodo per tornare Token: (ritorno loginReponse --> quindi mi serve un Dto associato)
	// qua non uso gli optional perchè l'utente so che è già presente
	
	public UtenteLoginResponseDto issueToken(String email) {
		// creazione chiave segreta: 
		byte[] secret = "stringachiave1234567891111111111".getBytes();
		
		Key chiaveSegreta = Keys.hmacShaKeyFor(secret);
		
		Utente informazioniUtente = utenteService.findByEmail(email);
		
		//Adesso si devono riprendere le info dell'utente --> HashMap, Object passa qualsiasi tipo di valore
		Map<String, Object> mappa = new HashMap<>();
		
		mappa.put("nome", informazioniUtente.getNome());
		mappa.put("cognome", informazioniUtente.getCognome());
		mappa.put("email", email);
		
		//adesso faccio i ruoli: 
		List<String> ruoli = new ArrayList<>();
		
		//vado a ciclare la lista dei ruoli e aggiungo i parametri alla lista
		informazioniUtente.getRuoli().forEach(r -> ruoli.add(r.getTipologia())); //perchè ho l'enum all'interno --> r.getTipologia().name())
		
		//inserisco all'interno della mappa
		mappa.put("ruoli", ruoli);
		
		
		// creazione data creazione e data fine:
		Date creation = new Date();
		Date end = java.sql.Timestamp.valueOf(LocalDateTime.now().plusMinutes(15L)); //creo data fine del token con timestamp + 15 minuti aggiunti
		
		
		//creazione del Token: 
		//claims = prorpietà | issue chi mette il token | tempo in cui viene messo e in cui morirà | chiave con cui firmare
		String jwtToken = Jwts.builder().setClaims(mappa)
				.setIssuer("http://localhost:8080")
				.setIssuedAt(creation)
				.setExpiration(end)
				.signWith(chiaveSegreta)
				.compact();
				
		UtenteLoginResponseDto token = new UtenteLoginResponseDto();
		
		token.setToken(jwtToken);
		token.setTtl(end);
		token.setTokenCreationTime(creation);
		
		return token;
	}
	
	
	
}
