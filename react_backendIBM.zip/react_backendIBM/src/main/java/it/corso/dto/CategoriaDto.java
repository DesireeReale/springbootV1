package it.corso.dto;

public class CategoriaDto {

	private int id_ca;
	private String nome_categoria;
	public int getId_ca() {
		return id_ca;
	}
	public void setId_ca(int id_ca) {
		this.id_ca = id_ca;
	}
	public String getNome_categoria() {
		return nome_categoria;
	}
	public void setNome_categoria(String nome_categoria) {
		this.nome_categoria = nome_categoria;
	}
	public CategoriaDto(int id_ca, String nome_categoria) {
		super();
		this.id_ca = id_ca;
		this.nome_categoria = nome_categoria;
	} 
	
	public CategoriaDto() {
		super();
	}
}
