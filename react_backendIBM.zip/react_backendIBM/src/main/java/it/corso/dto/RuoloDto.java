package it.corso.dto;


public class RuoloDto {
	
	private Integer id;
	
	private String tipologia;
	
	public RuoloDto() {
		super();
		
	}

	public String getTipologia() {
		return tipologia;
	}

	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	public RuoloDto(Integer id, String tipologia) {
		super();
		this.id = id;
		this.tipologia = tipologia;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
}
