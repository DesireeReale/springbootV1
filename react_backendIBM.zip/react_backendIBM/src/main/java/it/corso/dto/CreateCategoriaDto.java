package it.corso.dto;

public class CreateCategoriaDto {

	private String nome_categoria;

	public String getNome_categoria() {
		return nome_categoria;
	}

	public void setNome_categoria(String nome_categoria) {
		this.nome_categoria = nome_categoria;
	}
	
	
}
