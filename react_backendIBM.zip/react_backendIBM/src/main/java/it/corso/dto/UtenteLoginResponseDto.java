package it.corso.dto;

import java.util.Date;

public class UtenteLoginResponseDto {

	//mi servono i campi per poter prendere le info lato frontend
	
	private String token; 
	
	private Date ttl; //time to live
	
	private Date tokenCreationTime; //definisce la data di creazione del token (dopo un tot di tempo non è più valido)
	

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Date getTtl() {
		return ttl;
	}

	public void setTtl(Date ttl) {
		this.ttl = ttl;
	}

	public Date getTokenCreationTime() {
		return tokenCreationTime;
	}

	public void setTokenCreationTime(Date tokenCreationTime) {
		this.tokenCreationTime = tokenCreationTime;
	}
	
	
}
