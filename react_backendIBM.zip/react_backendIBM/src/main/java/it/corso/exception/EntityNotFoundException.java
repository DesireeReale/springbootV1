package it.corso.exception;

public class EntityNotFoundException extends Exception{
	
	public EntityNotFoundException(String message) {
		super(message);
	}

}
